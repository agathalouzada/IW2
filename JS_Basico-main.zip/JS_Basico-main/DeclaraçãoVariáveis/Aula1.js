// o js aceita as duas formas tanto escrevendo var ou n

/* 
var nome = 'Thifany'
idade = '16 anos'
var saldo = '0,15'
 */

nome = prompt("Qual é o seu nome?")
idade = parseInt(prompt("Qual é a sua idade?"))
curso = prompt("Qual é o seu curso?")

